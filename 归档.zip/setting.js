module.exports = {
    cookieSecret: 'myApp',
    db: 'appWet',
    host: 'localhost',
    port: '27017'
};